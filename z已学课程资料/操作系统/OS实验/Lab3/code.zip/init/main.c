#include "printk.h"
#include "defs.h"

extern void test();

int start_kernel() {
    printk("2024");
    printk(" ZJU Operating System\n");

    // uint64_t result;
    // result = csr_read(sstatus);
    // printk("csr_read result : %llx\n", result);
    
    // uint64_t writeIn = 0x12345678, result = 0x0;
    // csr_write(sscratch, writeIn);
    // result = csr_read(sscratch);
    // printk("csr_read result : %llx\n", result);

    test();
    return 0;
}
