#include "stdint.h"
#include "printk.h"
#include "sbi.h"   
#include "clock.h"
#include "proc.h"

#define SCAUSE_INTERRUPT_MASK 0x8000000000000000 // 中断标志位
#define SUPERVISOR_TIMER_INTERRUPT_ID 5 // 时钟中断 ID

void trap_handler(uint64_t scause, uint64_t sepc) {
    // 检查中断类型
    if (scause & SCAUSE_INTERRUPT_MASK) {
        // 这是一个中断
        uint64_t interrupt_id = scause & 0x7FFFFFFF; // 获取中断 ID
        
        // 检查是否是时钟中断
        if (interrupt_id == SUPERVISOR_TIMER_INTERRUPT_ID) {
            // 打印调试信息
            printk("[S] Supervisor Mode Timer Interrupt\n");
            
            // 处理时钟中断，设置下一个时钟中断
            clock_set_next_event();

            //线程运行时间自减
            do_timer();
            
        } else {
            // 其他中断可以直接忽略，打印以供调试
            printk("Unhandled interrupt: interrupt_id = %lu\n", interrupt_id);
        }
    } else {
        // 这是一个异常
        printk("Unhandled exception: scause = %lu, sepc = %lu\n", scause, sepc);
    }
}

