#include "mm.h"
#include "defs.h"
#include "proc.h"
#include "stdlib.h"
#include "printk.h"

extern void __dummy();

struct task_struct *idle;           // idle process
struct task_struct *current;        // 指向当前运行线程的 task_struct
struct task_struct *task[NR_TASKS]; // 线程数组，所有的线程都保存在此

// 线程初始化函数
void task_init() {
    srand(2024);  // 设置随机种子

    // 1. 调用 kalloc() 为 idle 分配一个物理页
    // 2. 设置 state 为 TASK_RUNNING;
    // 3. 由于 idle 不参与调度，可以将其 counter / priority 设置为 0
    // 4. 设置 idle 的 pid 为 0
    // 5. 将 current 和 task[0] 指向 idle

    // 为 idle 分配物理页
    idle = (struct task_struct *)kalloc();
    if (idle == NULL) {
        printk("Failed to allocate page for idle task\n");
        return;
    }

    // 初始化 idle 线程
    idle->state = TASK_RUNNING;  // 设置状态为运行态
    idle->counter = 0;           // 不参与调度，counter 设置为 0
    idle->priority = 0;          // 优先级也设置为 0
    idle->pid = 0;               // pid 设置为 0

    current = idle;              // current 指向 idle
    task[0] = idle;              // task[0] 也指向 idle

    // 1. 参考 idle 的设置，为 task[1] ~ task[NR_TASKS - 1] 进行初始化
    // 2. 其中每个线程的 state 为 TASK_RUNNING, 此外，counter 和 priority 进行如下赋值：
    //     - counter  = 0;
    //     - priority = rand() 产生的随机数（控制范围在 [PRIORITY_MIN, PRIORITY_MAX] 之间）
    // 3. 为 task[1] ~ task[NR_TASKS - 1] 设置 thread_struct 中的 ra 和 sp
    //     - ra 设置为 __dummy（见 4.2.2）的地址
    //     - sp 设置为该线程申请的物理页的高地址

    // 为其他线程分配物理页并初始化
    for (int i = 1; i < NR_TASKS; i++) {
        task[i] = (struct task_struct *)kalloc();  // 分配物理页
        if (task[i] == NULL) {
            printk("Failed to allocate page for task %d\n", i);
            return;
        }

        // 设置线程的状态和调度信息
        task[i]->state = TASK_RUNNING;
        task[i]->counter = 0;
        task[i]->priority = (rand() % (PRIORITY_MAX - PRIORITY_MIN + 1)) + PRIORITY_MIN;  // 随机优先级

        // 设置线程的 thread_struct 中的 ra 和 sp
        task[i]->thread.ra = (uint64_t)__dummy;  // ra 设置为 __dummy 的地址
        task[i]->thread.sp = (uint64_t)task[i] + PGSIZE;  // sp 指向物理页的高地址
        task[i]->pid = i;  // pid 设置为当前的索引值
    }

    printk("...task_init done!\n");
}

#if TEST_SCHED
#define MAX_OUTPUT ((NR_TASKS - 1) * 10)  // 定义调度输出的最大字符数
char tasks_output[MAX_OUTPUT];            // 保存任务的输出结果
int tasks_output_index = 0;               // 记录当前输出的索引位置
char expected_output[] = "2222222222111111133334222222222211111113";  // 期望的输出，用于测试调度顺序
#include "sbi.h"                          // 引入 SBI（Supervisor Binary Interface）头文件，用于系统关机等操作
#endif


void dummy() {
    uint64_t MOD = 1000000007;  // 用于计算的模数，防止变量溢出
    uint64_t auto_inc_local_var = 0;  // 局部自增变量，用于模拟一些线程的工作
    int last_counter = -1;  // 上一次的 `counter` 值，用于检测是否有新的调度

    while (1) {
        // 如果当前线程的 `counter` 发生变化，并且大于0，才会执行此逻辑
        if ((last_counter == -1 || current->counter != last_counter) && current->counter > 0) {

            // if (current->counter == 1) {
            //     --(current->counter);   // forced the counter to be zero if this thread is going to be scheduled
            // }                           // in case that the new counter is also 1, leading the information not printed.
            
            // 更新 `last_counter`，记录当前的 counter 值
            last_counter = current->counter;

            // 自增局部变量，模拟线程内部的工作
            auto_inc_local_var = (auto_inc_local_var + 1) % MOD;

            // 打印当前线程的 pid 和局部变量值，表明该线程正在运行
            printk("[PID = %d] is running. auto_inc_local_var = %d current_counter = %d\n", current->pid, auto_inc_local_var, current->counter);

            #if TEST_SCHED
            // 记录当前运行线程的 PID 到 tasks_output 中，用于调度测试
            tasks_output[tasks_output_index++] = current->pid + '0';

            // 如果已经记录了所有的调度输出（达到 MAX_OUTPUT 次）
            if (tasks_output_index == MAX_OUTPUT) {
                // 检查输出是否符合期望
                for (int i = 0; i < MAX_OUTPUT; ++i) {
                    if (tasks_output[i] != expected_output[i]) {
                        // 如果输出不符合预期，打印失败信息并关机
                        printk("\033[31mTest failed!\033[0m\n");
                        printk("\033[31m    Expected: %s\033[0m\n", expected_output);
                        printk("\033[31m    Got:      %s\033[0m\n", tasks_output);
                        sbi_system_reset(SBI_SRST_RESET_TYPE_SHUTDOWN, SBI_SRST_RESET_REASON_NONE);  // 系统关机
                    }
                }
                // 如果输出符合预期，打印通过信息并关机
                printk("\033[32mTest passed!\033[0m\n");
                printk("\033[32m    Output: %s\033[0m\n", expected_output);
                sbi_system_reset(SBI_SRST_RESET_TYPE_SHUTDOWN, SBI_SRST_RESET_REASON_NONE);  // 系统关机
            }
            #endif
        }
    }
}

extern void __switch_to(struct task_struct* prev, struct task_struct* next);

void switch_to(struct task_struct* next) {
    if (next == current) return; 
    else {
        struct task_struct* current_saved = current;
        current = next;
        __switch_to(current_saved, next);
    }
}

void do_timer(void) {
    // 1. 如果当前线程是 idle 线程或当前线程时间片耗尽则直接进行调度
    // 2. 否则对当前线程的运行剩余时间减 1，若剩余时间仍然大于 0 则直接返回，否则进行调度
    if (current == task[0]) schedule();
    else {
        //if (current->counter == 0) schedule();
        current->counter -= 1;
        if (current->counter == 0) schedule();
    }
}

//priority 调度
void schedule(void) {
    uint64_t maxCounter, i, next;
    struct task_struct** pointer;

    while (1) {
        maxCounter = 0;  // 初始化最大剩余时间片（counter）为0
        next = 0;        // 初始化下一个调度的任务索引为0（默认 idle 任务）
        i = NR_TASKS;    // 从任务列表末尾开始遍历
        pointer = &task[NR_TASKS];  // 指针指向任务数组的末尾

        // 遍历所有任务，选择状态为 TASK_RUNNING 且剩余时间片最多的任务
        while (--i) {  // 遍历 task[NR_TASKS-1] 到 task[1]
            if (!*--pointer) continue;  // 如果任务不存在，跳过
            // 如果任务是 RUNNING 状态，且剩余时间片大于当前最大值，则更新 maxCounter 和 next
            if ((*pointer)->state == TASK_RUNNING && (*pointer)->counter > maxCounter) {
                maxCounter = (*pointer)->counter;  // 更新最大剩余时间片
                next = i;  // 记录该任务的索引，表示它是下一个要调度的任务
            }
        }

        // 如果找到了一个剩余时间片大于0的任务，退出循环
        if (maxCounter > 0) break;

        // 如果所有任务的 counter 都为 0，进行时间片重新分配
        printk("\n");

        // 遍历所有任务，重新分配时间片
        for (pointer = &task[NR_TASKS-1]; pointer > &task[0]; --pointer) {
            if (*pointer) {
                // 重新计算时间片：右移1位相当于除以2，然后加上任务的优先级
                (*pointer)->counter = ((*pointer)->counter >> 1) + (*pointer)->priority;
                // 输出调度信息，打印该任务的 PID、优先级和重新分配后的 counter
                printk("SET [PID = %d PRIORITY = %d COUNTER = %d]\n", (*pointer)->pid, (*pointer)->priority, (*pointer)->counter);
            }
        }
    }

    // 输出即将切换的任务信息，包括 PID、优先级和剩余时间片
    printk("\nswitch to [PID = %d PRIORITY = %d COUNTER = %d]\n", task[next]->pid, task[next]->priority, task[next]->counter);
    
    // 切换到选中的任务
    switch_to(task[next]);
}


