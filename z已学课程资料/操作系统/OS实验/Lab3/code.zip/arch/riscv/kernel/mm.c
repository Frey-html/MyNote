#include "mm.h"       // 包含与内存管理相关的头文件
#include "defs.h"      // 包含基本的类型定义和常量
#include "string.h"    // 用于调用 memset 函数
#include "printk.h"    // 用于打印信息

// _ekernel 是内核结束的地址，由链接器提供，表示内核使用的内存结束位置
extern char _ekernel[];  

// 内存管理器结构体，维护了一个空闲页链表的头指针
struct {
    struct run *freelist;  // 空闲页链表的头
} kmem;

// 分配一个物理页（4 KiB）
void *kalloc() {
    struct run *r;

    // 获取空闲页链表的头，即第一个空闲页
    r = kmem.freelist;

    // 更新空闲页链表的头，指向下一个空闲页
    kmem.freelist = r->next;
    
    // 将分配的页内容清零（出于安全考虑）
    memset((void *)r, 0x0, PGSIZE);  // PGSIZE 通常是 4096，即 4 KiB

    // 返回分配的物理页地址
    return (void *)r;
}

// 释放一个物理页
void kfree(void *addr) {
    struct run *r;

    // 对地址进行页对齐（如果传入的地址不是按 PGSIZE 对齐，这里会对其处理）
    *(uintptr_t *)&addr = (uintptr_t)addr & ~(PGSIZE - 1);  // PGSIZE - 1 = 0xFFF，按 4KiB 对齐

    // 清空这页的内容（出于安全考虑）
    memset(addr, 0x0, (uint64_t)PGSIZE);

    // 将这页重新插入到空闲页链表的头部
    r = (struct run *)addr;
    r->next = kmem.freelist;
    kmem.freelist = r;

    return;
}

// 将 [start, end] 范围内的内存标记为空闲
void kfreerange(char *start, char *end) {
    // 将起始地址按页大小对齐
    char *addr = (char *)PGROUNDUP((uintptr_t)start);

    // 遍历每一页，释放并将它们加入到空闲页链表
    for (; (uintptr_t)(addr) + PGSIZE <= (uintptr_t)end; addr += PGSIZE) {
        kfree((void *)addr);
    }
}

// 初始化内存管理系统
void mm_init(void) {
    // 将从 _ekernel 到 PHY_END 之间的内存全部标记为空闲
    kfreerange(_ekernel, (char *)VM_START+PHY_SIZE);
    printk("...mm_init done!\n");  // 打印内存管理初始化完成的日志
}
