package org.example;

import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.store.*;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

import java.io.File;
import java.io.IOException;

public class Indexer {
    private static final String INDEX_DIR = "index";  // 存放索引的目录

    public static void createIndex(File documentFile) throws IOException {
        Directory dir = FSDirectory.open(new File(INDEX_DIR).toPath());
        StandardAnalyzer analyzer = new StandardAnalyzer();
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter writer = new IndexWriter(dir, config);

        // 创建文档
        Document doc = new Document();
        doc.add(new StringField("path", documentFile.getAbsolutePath(), Field.Store.YES));
        doc.add(new TextField("content", extractContent(documentFile), Field.Store.YES));

        // 添加文档到索引
        writer.addDocument(doc);
        writer.close();
    }

    // 提取文档内容（根据文件类型使用Tika或Jsoup）
    private static String extractContent(File file) throws IOException {
        if (file.getName().endsWith(".html")) {
            return HtmlExtractor.extractText(file);
        } else {
            return DocumentExtractor.extractText(file);
        }
    }
}
