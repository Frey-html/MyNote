package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.IOException;

public class HtmlExtractor {
    public static String extractText(File htmlFile) throws IOException {
        Document doc = Jsoup.parse(htmlFile, "UTF-8");
        // 提取标题
        String title = doc.title();
        // 提取正文内容
        Element body = doc.body();
        String bodyText = body.text();

        return "Title: " + title + "\nContent: " + bodyText;
    }
}
