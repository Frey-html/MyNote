package org.example;

import org.apache.tika.Tika;
import java.io.File;
import java.io.IOException;

public class DocumentExtractor {
    private static final Tika tika = new Tika();

    // 提取文本内容
    public static String extractText(File file) throws IOException {
        return tika.parseToString(file);
    }
}
