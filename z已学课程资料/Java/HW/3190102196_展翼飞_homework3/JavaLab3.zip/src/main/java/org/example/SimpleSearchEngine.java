package org.example;

import org.example.Indexer;
import org.example.Searcher;

import java.io.File;
import java.util.Scanner;

public class SimpleSearchEngine {
    public static void main(String[] args) throws Exception {
        // 创建索引
        File dir = new File("docs");
        for (File file : dir.listFiles()) {
            if (file.isFile()) {
                Indexer.createIndex(file);
            }
        }

        // 用户输入搜索关键词
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter search query:");
        String query = scanner.nextLine();

        // 执行搜索
        Searcher.search(query);
    }
}
