package org.example;

import org.apache.lucene.search.*;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.store.*;

public class Searcher {
    private static final String INDEX_DIR = "index";

    public static void search(String queryStr) throws Exception {
        Directory dir = FSDirectory.open(new File(INDEX_DIR).toPath());
        DirectoryReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);

        QueryParser parser = new QueryParser("content", new StandardAnalyzer());
        Query query = parser.parse(queryStr);

        TopDocs topDocs = searcher.search(query, 10);  // 返回前10个结果

        System.out.println("Found " + topDocs.totalHits.value + " documents:");
        for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
            org.apache.lucene.document.Document doc = searcher.doc(scoreDoc.doc);
            System.out.println(doc.get("path"));
        }
    }
}
