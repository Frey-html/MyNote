#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QDebug"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("2048");
    setFixedSize(800, 600);
    //设置背景色
    QPalette pal(this->palette());
    pal.setColor(QPalette::Background, BkgColor);
    this->setAutoFillBackground(true);
    this->setPalette(pal);
    //设置按钮样式
    ui->singlePlayer->setFont(ButtonFont);
    ui->singlePlayer->setStyleSheet(BtnStyleSheet);
    ui->doublePlayer->setFont(ButtonFont);
    ui->doublePlayer->setStyleSheet(BtnStyleSheet);
    ui->robotPlayer->setFont(ButtonFont);
    ui->robotPlayer->setStyleSheet(BtnStyleSheet);
    ui->onlinePlayer->setFont(ButtonFont);
    ui->onlinePlayer->setStyleSheet(BtnStyleSheet);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_singlePlayer_clicked()
{
    game * newGame = new game(this);
    //将部件设置为窗口！！否则show也不会显示
    newGame->setWindowFlag(Qt::Window);
    newGame->setGameMode(SinglePlayer);
    newGame->initialize();
    newGame->show();
    this->hide();
}

void MainWindow::on_doublePlayer_clicked()
{
    game * newGame = new game(this);
    //将部件设置为窗口！！否则show也不会显示
    newGame->setWindowFlag(Qt::Window);
    newGame->setGameMode(DoublePlayer);
    newGame->initialize();
    newGame->show();
    this->hide();
}

void MainWindow::on_robotPlayer_clicked()
{
    game * newGame = new game(this);
    //将部件设置为窗口！！否则show也不会显示
    newGame->setWindowFlag(Qt::Window);
    newGame->setGameMode(RobotPlayer);
    newGame->initialize();
    newGame->show();
    this->hide();
}

void MainWindow::on_onlinePlayer_clicked()
{
    game * newGame = new game(this);
    //将部件设置为窗口！！否则show也不会显示
    newGame->setWindowFlag(Qt::Window);
    newGame->setGameMode(DoublePlayer);
    newGame->initialize();
    newGame->show();
    this->hide();
}
