# game

2022课程综合实践Ⅱ C++项目  

开发工具：C++ Qt(5.9.9)  
 
编译过程：需安装相应版本Qt，通过game.pro打开项目，选择debug或release模式，Ctrl+R进行编译
