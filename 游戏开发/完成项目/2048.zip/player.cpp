#include "player.h"
#include <QDebug>

Player::Player(PlayerType t, QPoint origin):type(t), origin(origin){
    qDebug()<<"constructor called";
    memset(board, 0, sizeof(board));
    score = 0;
    waiting = false;
    count = 2;
    //初始化棋盘 填入两个2
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    int judge = rand() % 2;
    int judge2 = rand() % 2;
    qDebug() <<judge<<judge2;
    board[rand() % MySize][rand() % MySize] = (judge == 0)?2:4;
    int nextX, nextY;
    nextX = rand() % MySize;
    nextY = rand() % MySize;
    while(board[nextX][nextY] != 0){
        nextX = rand() % MySize;
        nextY = rand() % MySize;
    }
    board[nextX][nextY] = (judge2 == 0)?2:4;
//    //debug
//    qDebug() << "initialize to"<<nextX<<nextY<<endl;
//    //debug
//    qDebug()<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<" "<<board[0][3]<<endl;
//    qDebug()<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<" "<<board[1][3]<<endl;
//    qDebug()<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<" "<<board[2][3]<<endl;
//    qDebug()<<board[3][0]<<" "<<board[3][1]<<" "<<board[3][2]<<" "<<board[3][3]<<endl;
}

void Player::updateBoard(int key){
    if(waiting) return;
    bool combined[MySize][MySize]; //当前格子是否已经经过合并，每次操作每个数字最多合并一次
    memset(combined, 0, sizeof(combined));
    bool move = false, combine = false; //本次操作是否产生更新，若没有则不需要重新生成随机数
    Animation animate; //记录操作过程中产生的动画需求
    int temp; //用于交换

    //进行按键判断，进行棋盘更新与动画需求记录
    if(key == Qt::Key_A){
        for(int i = 0;i < MySize;i++){
            //从一行的第一列k = 0开始到最后一列k = Size - 1，j每次向后探测
            //将第一个不为零的值移动到k的位置，记录一次移动
            //若k当前可以和k-1的列的值合并，则k位置置0，记录一次合并
            int j = 0, k = 0;
            while(j < MySize){
                while(j < MySize && board[i][j] == 0) j++;
                if(j == MySize) break;
                //发生移动，记录移动动画
                if(j != k){
                    move = true;
                }
                //重要！：如果没有发生实际的运动，即方块留在原地，也要记录一次动画
                //只不过起点等于终点，否则没有运动的方块不会在动画重绘的过程中显示
                temp = board[i][k];
                board[i][k] = board[i][j];
                board[i][j] = temp;
                animate.type = MOVE;
                animate.digitStart = animate.digitEnd = board[i][k];
                //设置动画起始与终止位置
                //坐标为相应格子(cell)的左上角顶点坐标
                animate.startPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                                          origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                animate.endPos = QPoint(origin.x() + MyBoardWOfs + k * MyCellSize + MyCellGap,
                        origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                animate.direct = Qt::Key_A;
                //发生合并，记录数值变化，增加分数，存在的数值个数减1
                if(k > 0 && board[i][k] == board[i][k-1] && !combined[i][k]){
                    combine = true;
                    board[i][k-1] *= 2;
                    board[i][k] = 0;
                    score += board[i][k-1];
                    //发生合并，修改动画终止位置与终止时数字显示
                    animate.digitEnd = board[i][k-1];
                    animate.endPos = QPoint(origin.x() + MyBoardWOfs + (k - 1) * MyCellSize + MyCellGap,
                            origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                    combined[i][k-1] = true;
                    count--;
                }
                else k++; //如果发生合并，则继续把后续非0值移动到k这一格
                j++;
                animationList.push_back(animate);
            }
        }
    }
    if(key == Qt::Key_W){
        for(int j = 0;j < MySize;j++){
            int i = 0, k = 0;
            while(i < MySize){
                while(i < MySize && board[i][j] == 0) i++;
                if(i == MySize) break;
                if(i != k){
                    move = true;
                }
                temp = board[k][j];
                board[k][j] = board[i][j];
                board[i][j] = temp;
                animate.type = MOVE;
                animate.digitStart = animate.digitEnd = board[k][j];
                animate.startPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                                          origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                animate.endPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                        origin.y() + MyBoardHOfs + k * MyCellSize + MyCellGap);
                animate.direct = Qt::Key_W;
                if(k > 0 && board[k][j] == board[k-1][j] && !combined[k-1][j]){
                    combine = true;
                    board[k-1][j] *= 2;
                    board[k][j] = 0;
                    score += board[k-1][j];
                    animate.digitEnd = board[k-1][j];
                    animate.endPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                            origin.y() + MyBoardHOfs + (k-1) * MyCellSize + MyCellGap);
                    combined[i][k-1] = true;
                    count--;
                }
                else k++;
                i++;
                animationList.push_back(animate);
            }
        }
    }
    if(key == Qt::Key_S){
        for(int j = 0;j < MySize;j++){
            int i = MySize - 1, k = MySize - 1;
            while(i >= 0){
                while(i >=0 && board[i][j] == 0) i--;
                if(i < 0) break;
                if(i != k){
                    move = true;
                }
                temp = board[k][j];
                board[k][j] = board[i][j];
                board[i][j] = temp;
                animate.type = MOVE;
                animate.digitStart = animate.digitEnd = board[k][j];
                animate.startPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                                          origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                animate.endPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                        origin.y() + MyBoardHOfs + k * MyCellSize + MyCellGap);
                animate.direct = Qt::Key_S;

                if(k < MySize - 1 && board[k][j] == board[k+1][j] && !combined[k+1][j]){
                    combine = true;
                    board[k+1][j] *= 2;
                    board[k][j] = 0;
                    score += board[k+1][j];
                    animate.digitEnd = board[k+1][j];
                    animate.endPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                            origin.y() + MyBoardHOfs + (k+1) * MyCellSize + MyCellGap);
                    combined[i][k+1] = true;
                    count--;
                }
                else k--;
                i--;
                animationList.push_back(animate);
            }
        }
    }
    if(key == Qt::Key_D){
        for(int i = 0;i < MySize;i++){
            int j = MySize - 1, k = MySize - 1;
            while(j >= 0){
                while(j>= 0 && board[i][j] == 0) j--;
                if(j < 0) break;
                if(j != k){
                    move = true;
                }
                temp = board[i][k];
                board[i][k] = board[i][j];
                board[i][j] = temp;
                animate.type = MOVE;
                animate.digitStart = animate.digitEnd = board[i][k];
                animate.startPos = QPoint(origin.x() + MyBoardWOfs + j * MyCellSize + MyCellGap,
                                          origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                animate.endPos = QPoint(origin.x() + MyBoardWOfs + k * MyCellSize + MyCellGap,
                        origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                animate.direct = Qt::Key_D;
                if(k < MySize - 1 && board[i][k] == board[i][k+1] && !combined[i][k+1]){
                    combine = true;
                    board[i][k+1] *= 2;
                    board[i][k] = 0;
                    score += board[i][k+1];
                    animate.digitEnd = board[i][k+1];
                    animate.endPos = QPoint(origin.x() + MyBoardWOfs + (k + 1) * MyCellSize + MyCellGap,
                            origin.y() + MyBoardHOfs + i * MyCellSize + MyCellGap);
                    combined[i][k+1] = true;
                    count--;
                }
                else k--;
                j--;
                animationList.push_back(animate);
            }
        }
    }
    //若产生有效操作且棋盘不满
    if((move || combine) && count != MySize * MySize){
        //新生成一个2
        int nextX, nextY;
        int judge = rand() % 2;
        nextX = rand() % MySize;
        nextY = rand() % MySize;
        while(board[nextX][nextY] != 0){
            nextX = rand() % MySize;
            nextY = rand() % MySize;
        }
        board[nextX][nextY] = (judge == 0)? 2:4;
        //加入一个出现动画
        animate.type = APPEARANCE;
        animate.digitStart = animate.digitEnd = board[nextX][nextY];
        //动画效果为在相应格子中心绘制小的图形并逐渐放大到正常大小
        animate.startPos = QPoint(origin.x() + MyBoardWOfs + nextY * MyCellSize + MyCellGap + MyCellSize / 2,
                                  origin.y() + MyBoardHOfs + nextX * MyCellSize + MyCellGap + MyCellSize / 2);
        animate.endPos = QPoint(origin.x() + MyBoardWOfs + nextY * MyCellSize + MyCellGap,
                                origin.y() + MyBoardHOfs + nextX * MyCellSize + MyCellGap);
        //debug
        qDebug()<<"new num in"<<nextX<<nextY<<endl;
        animationList.push_back(animate);
        count++;
    }
    //设置标志为开始绘制动画，暂停读取相应用户输入
    waiting = true;
    //debug
//    qDebug()<<board[0][0]<<" "<<board[0][1]<<" "<<board[0][2]<<" "<<board[0][3]<<endl;
//    qDebug()<<board[1][0]<<" "<<board[1][1]<<" "<<board[1][2]<<" "<<board[1][3]<<endl;
//    qDebug()<<board[2][0]<<" "<<board[2][1]<<" "<<board[2][2]<<" "<<board[2][3]<<endl;
//    qDebug()<<board[3][0]<<" "<<board[3][1]<<" "<<board[3][2]<<" "<<board[3][3]<<endl;
}

void Player::restartGame(){
    memset(board, 0, sizeof(board));
    score = 0;
    waiting = false;
    count = 2;
    //初始化棋盘 填入两个2
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    board[rand() % MySize][rand() % MySize] = 2;
    int nextX, nextY;
    nextX = rand() % MySize;
    nextY = rand() % MySize;
    while(board[nextX][nextY] != 0){
        nextX = rand() % MySize;
        nextY = rand() % MySize;
    }
    board[nextX][nextY] = 2;
}
