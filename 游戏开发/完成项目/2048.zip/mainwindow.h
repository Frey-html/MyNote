#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "game.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_singlePlayer_clicked();

    void on_doublePlayer_clicked();

    void on_robotPlayer_clicked();

    void on_onlinePlayer_clicked();

private:
    Ui::MainWindow *ui;
    game * gameWindow;
};

#endif // MAINWINDOW_H
