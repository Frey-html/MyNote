#ifndef CONFIGURE_H
#define CONFIGURE_H
#include <QColor>
#include <QPoint>
#include <QFont>

#define MySize 4 //棋盘格子行列数
#define MyWindowWidth 800.0 //游戏窗口宽度（单人模式）
#define MyWindowHeight 800.0 //游戏窗口高度
#define MyBoardSize (MyWindowWidth * 0.75) //游戏棋盘大小
#define MyBoardWOfs ((MyWindowWidth - MyBoardSize) / 2.0) //游戏棋盘水平偏移距离
#define MyBoardHOfs ((MyWindowHeight - MyBoardSize) / 1.5) //游戏棋盘列偏移
#define MyCellSize (MyBoardSize / MySize) //数字方格大小
#define MyCellGap (MyBoardSize / 48.0) //数字方格间距
#define BtnStyleSheet "QPushButton {background-color:#FDF5E6;color:#A0522D}"

//背景颜色定义
const QColor BkgColor("#FFFAF8");
const QColor BoardBkg("#FFCCAA");
const QColor CellBkg[12] = {
    QColor("#FFDAB9"),QColor("#F4C000"),
    QColor("#F08080"),QColor("#FFbb66"),
    QColor("#DEB887"),QColor("#FFA488"),
    QColor("#FA8072"),QColor("#FF7F50"),
    QColor("#CD5C5C"),QColor("#BC8F8F"),
    QColor("#FFAA33"),QColor("#FF4500")
};

//字体样式定义
//按钮字体样式
const QFont ButtonFont("幼圆", 10, QFont::Bold);
const QColor ButtonColor("#A0522D");
//默认字体样式 应用于分数显示等
const QColor DefaultColor("#A0522D");
const QFont DefaultFont("幼圆", 20, QFont::Bold);
const QColor DefaultBrush(0,0,0,70);
//方格中数值显示样式
const QFont DigitFont("Bauhaus 93", MyCellSize/6, 81, false);
const QColor LowerColor("#884400"); //数值小于等于4时字体颜色
const QColor HigherColor(Qt::white); //数值大于4时字体颜

//游戏模式
enum GameMode{
    SinglePlayer = 1,
    DoublePlayer = 2,
    RobotPlayer = 3,
    OnlinePlayer = 4
};

//玩家类型
enum PlayerType{
    Local = 1,
    Robot = 2,
    Online = 3
};

// 定义动画的类型
enum AnimationType
{
    MOVE,       // 方格移动
    APPEARANCE  // 方格出现
};

// 动画结构体
struct Animation
{
    AnimationType type;     // 动画类型
    int direct;             // 方向, 以Qt::key_W A S D 为通用标准
    QPointF startPos;       // 起始点坐标 出现动画仅仅使用这个坐标
    QPointF endPos;         // 终止点坐标 移动动画的终点坐标
    int digitStart;              // 被移动方格起始数值
    int digitEnd;             // 被移动方格终止数值 可能被合并
};

const int frameTime = 5; //每一帧动画时长（毫秒）
const qreal moveLength = MyCellSize / 14; //每一帧动画方格移动距离
const int robotDecide = 500; //机器人决策时间 ms

#endif // CONFIGURE_H
