#include "game.h"
#include "mainwindow.h"
#include <QApplication>
#include <QDesktopWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QDesktopWidget *desktop = QApplication::desktop();
    MainWindow mainWindow;
    //设置居中偏上显示
    mainWindow.setFixedSize(MyWindowWidth, MyWindowHeight / 1.3);
    mainWindow.move((desktop->width() - mainWindow.width())/ 2, (desktop->height() - mainWindow.height()) / 3);
    mainWindow.show();
    return a.exec();
}
