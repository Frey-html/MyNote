//玩家类，接收game类传来的操作信号，维护单个玩家的游戏数据
#ifndef PLAYER_H
#define PLAYER_H

#include <QKeyEvent>
#include <QTimer>
#include <QtGlobal>
#include <QTime>
#include "configure.h"

class Player
{
public:
    Player(PlayerType, QPoint origin = QPoint(0, 0));
    void updateBoard(int key);//接受操作输入，更新棋盘
    void restartGame(); //清空棋盘，重新开始游戏

friend class game;
private:
    PlayerType type; //玩家类型
    QPoint origin; //玩家界面起始位置（左侧或右侧）
    int score; //玩家得分
    int count; //棋盘中数值个数（判断游戏终止）
    int board[4][4]; //游戏棋盘
    bool waiting; //是否正在播放动画
    QVector<Animation> animationList;//需要播放的动画列表
};

#endif // PLAYER_H
