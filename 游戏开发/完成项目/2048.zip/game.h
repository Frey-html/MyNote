#ifndef GAME_H
#define GAME_H

#include <QWidget>
#include <QPainter>
#include <QKeyEvent>
#include <QVector>
#include <QtGlobal>
#include <QPushButton>
#include <QMessageBox>
#include "configure.h"
#include "player.h"

QT_BEGIN_NAMESPACE
namespace Ui { class game; }
QT_END_NAMESPACE

class game : public QWidget
{
    Q_OBJECT

public:
    game(QWidget *parent = nullptr);
    ~game();
    void setGameMode(GameMode); //设置游戏模式
    void initialize(); //游戏参数初始化
    int valueToIndex(int value); //实现值到相应指数幂次即标志的转换 2^n -> n

    QPushButton *buttonRst; //重新开始按钮
    QPushButton *buttonHelp; //帮助按钮
    QPushButton *buttonRtn; //返回主界面按钮


protected:
    void keyPressEvent(QKeyEvent *); //处理用户输入
    void paintEvent(QPaintEvent *); //绘制事件

private slots:
    void slotHelp();
    void slotReturn();
    void checkWin();
    void checkLose();
    void robotUpdate();//人机通过定时器回调进行决策
    void restartGame(); //重新开始游戏

signals:
    void gameWin();

private:
    bool drawAnimation(QPainter& painter, int player); //进行动画绘制
    bool drawAnimationFrame(Animation& animate, QPainter& painter, bool moveDone); //绘制动画的一帧
    //bool checkWin();//检测游戏胜利 胜利条件：单人合成2048或者多人中有一人率先合成出2048
    //void checkLose();//检测游戏失败 失败条件：单人无法再行动或者多人同时无法行动（此时得分高者获胜）
    Ui::game *ui;
    GameMode gameMode; //游戏模式
    QVector<Player *> playerList; //维护游戏玩家界面
    QTimer timer_player0; //玩家0动画绘制计时器
    QTimer timer_player1; //玩家1动画绘制计时器
    QTimer gameOverCheck; //游戏结束检测计时器
    QTimer timer_robot;   //人机操作计时器
};
#endif // GAME_H
