#include "game.h"
#include "ui_game.h"
#include "QDebug"

game::game(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::game)
{
    ui->setupUi(this);
    setWindowTitle("2048Game");

    //设置背景色
    QPalette pal(this->palette());
    pal.setColor(QPalette::Background, BkgColor);
    this->setAutoFillBackground(true);
    this->setPalette(pal);

    buttonRst = new QPushButton(this);
    buttonRst->setGeometry(100,0,200,50);
    buttonRst->setText("重新开始");
    buttonRst->setFont(ButtonFont);
    buttonRst->setStyleSheet(BtnStyleSheet);
    qsrand(uint(QTime(0,0,0).secsTo(QTime::currentTime())));
    connect(buttonRst,SIGNAL(clicked()),this,SLOT(restartGame()));

    buttonHelp = new QPushButton(this);
    buttonHelp->setGeometry(0,0,100,50);
    buttonHelp->setText("帮助");//按钮中的文字
    buttonHelp->setFont(ButtonFont);
    buttonHelp->setStyleSheet(BtnStyleSheet);
    connect(buttonHelp,SIGNAL(clicked()),this,SLOT(slotHelp()));

    buttonRtn = new QPushButton(this);
    buttonRtn->setGeometry(300,0,200,50);
    buttonRtn->setText("返回");//按钮中的文字
    buttonRtn->setFont(ButtonFont);
    buttonRtn->setStyleSheet(BtnStyleSheet);
    connect(buttonRtn,SIGNAL(clicked()),this,SLOT(slotReturn()));

    //防止按钮占用方向键信号
    buttonRst->setFocusPolicy(Qt::ClickFocus);
    buttonHelp->setFocusPolicy(Qt::ClickFocus);
    buttonRtn->setFocusPolicy(Qt::ClickFocus);
    // 连接动画更新时钟信号和作画更新的槽
    connect(&timer_player0, SIGNAL(timeout()), this, SLOT(update()));
    connect(&timer_player1, SIGNAL(timeout()), this, SLOT(update()));
    connect(&gameOverCheck, SIGNAL(timeout()), this, SLOT(checkWin()));
    connect(&gameOverCheck, SIGNAL(timeout()), this, SLOT(checkLose()));
    //开启游戏结束检测
    gameOverCheck.start(frameTime * 10);
}

game::~game()
{
    delete ui;
}

void game::restartGame(){
    for(int i = 0;i < playerList.size();i++){
        playerList[i]->restartGame();
    }
    //重新渲染
    update();
    //焦点转移回主窗口防止按钮占用方向键信号
    this->setFocus();
}

void game::slotHelp(){
    QMessageBox::about(this,"游戏规则","WSAD或上下左右控制方块上下左右移动\n");
    //焦点转移回主窗口
    this->setFocus();
}
void game::slotReturn(){
    this->parentWidget()->show();
    delete this;
}

void game::robotUpdate(){
    int board[MySize][MySize]; //临时棋盘
    int temp = 0;

    int decision = Qt::Key_Up;
    int highestScore = 0;

    bool combined[MySize][MySize]; //当前格子是否已经经过合并，每次操作每个数字最多合并一次
    memset(combined, 0, sizeof(combined));

    //向上试探
    for(int i = 0;i < MySize;i++){
        for(int j = 0;j < MySize;j++){
            board[i][j] = playerList[1]->board[i][j];
        }
    }
    memset(combined, 0, sizeof(combined));
    int score = 0;
    for(int j = 0;j < MySize;j++){
        int i = 0, k = 0;
        while(i < MySize){
            while(i < MySize && board[i][j] == 0) i++;
            if(i == MySize) break;
            temp = board[k][j];
            board[k][j] = board[i][j];
            board[i][j] = temp;
            if(k > 0 && board[k][j] == board[k-1][j] && !combined[k-1][j]){
                board[k-1][j] *= 2;
                board[k][j] = 0;
                score += board[k-1][j];
                combined[i][k-1] = true;
            }
            else k++;
            i++;
        }
    }
    if(score > highestScore){
        highestScore = score;
        decision = Qt::Key_Up;
    }

    //向下试探
    for(int i = 0;i < MySize;i++){
        for(int j = 0;j < MySize;j++){
            board[i][j] = playerList[1]->board[i][j];
        }
    }
    memset(combined, 0, sizeof(combined));
    score = 0;
    for(int j = 0;j < MySize;j++){
        int i = MySize - 1, k = MySize - 1;
        while(i >= 0){
            while(i >=0 && board[i][j] == 0) i--;
            if(i < 0) break;
            temp = board[k][j];
            board[k][j] = board[i][j];
            board[i][j] = temp;
            if(k < MySize - 1 && board[k][j] == board[k+1][j] && !combined[k+1][j]){
                board[k+1][j] *= 2;
                board[k][j] = 0;
                score += board[k+1][j];
                combined[i][k+1] = true;
            }
            else k--;
            i--;
        }
    }
    if(score > highestScore){
        highestScore = score;
        decision = Qt::Key_Down;
    }

    //向左试探
    for(int i = 0;i < MySize;i++){
        for(int j = 0;j < MySize;j++){
            board[i][j] = playerList[1]->board[i][j];
        }
    }
    memset(combined, 0, sizeof(combined));
    score = 0;
    for(int j = 0;j < MySize;j++){
        int i = 0, k = 0;
        while(i < MySize){
            while(i < MySize && board[i][j] == 0) i++;
            if(i == MySize) break;
            temp = board[k][j];
            board[k][j] = board[i][j];
            board[i][j] = temp;
            if(k > 0 && board[k][j] == board[k-1][j] && !combined[k-1][j]){
                board[k-1][j] *= 2;
                board[k][j] = 0;
                score += board[k-1][j];
                combined[i][k-1] = true;
            }
            else k++;
            i++;
        }
    }
    if(score > highestScore){
        highestScore = score;
        decision = Qt::Key_Left;
    }

    //向右试探
    for(int i = 0;i < MySize;i++){
        for(int j = 0;j < MySize;j++){
            board[i][j] = playerList[1]->board[i][j];
        }
    }
    memset(combined, 0, sizeof(combined));
    score = 0;
    for(int i = 0;i < MySize;i++){
        int j = MySize - 1, k = MySize - 1;
        while(j >= 0){
            while(j>= 0 && board[i][j] == 0) j--;
            if(j < 0) break;
            temp = board[i][k];
            board[i][k] = board[i][j];
            board[i][j] = temp;
            if(k < MySize - 1 && board[i][k] == board[i][k+1] && !combined[i][k+1]){
                board[i][k+1] *= 2;
                board[i][k] = 0;
                score += board[i][k+1];
                combined[i][k+1] = true;
            }
            else k--;
            j--;
        }
    }
    if(score > highestScore){
        highestScore = score;
        decision = Qt::Key_Right;
    }

    //debug
    qDebug()<<"robot press";
    switch (decision){
        case Qt::Key_Up:{
            qDebug()<<"up"<<endl;
            break;
        }
        case Qt::Key_Down:{
            qDebug()<<"Down"<<endl;
            break;
        }
        case Qt::Key_Left:{
            qDebug()<<"Left"<<endl;
            break;
        }
        case Qt::Key_Right:{
            qDebug()<<"Right"<<endl;
            break;
        }
    }
    qDebug()<<highestScore<<endl;
    if(highestScore == 0){
        int randomNum = rand()%4;
        switch(randomNum){
            case 0: decision = Qt::Key_Up;break;
            case 1: decision = Qt::Key_Down;break;
            case 2: decision = Qt::Key_Left;break;
            case 3: decision = Qt::Key_Right;break;
        }
    }
    QKeyEvent * e = new QKeyEvent(QEvent::KeyPress, decision, 0);
    keyPressEvent(e);
}


void game::setGameMode(GameMode m){
   this->gameMode = m;
   //debug
   qDebug() << "gamemode set to" << (int)m;
}

void game::initialize(){
    //生成随机数种子
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    switch(gameMode){
    case SinglePlayer:{
            setFixedSize(MyWindowWidth, MyWindowHeight);
            Player * newPlayer = new Player(PlayerType::Local);
            playerList.push_back(newPlayer);
            break;
        }
    case DoublePlayer:{
            setFixedSize(MyWindowWidth * 2 - MyBoardWOfs, MyWindowHeight);
            Player * Player1 = new Player(PlayerType::Local);
            playerList.push_back(Player1);
            Player * Player2 = new Player(PlayerType::Local, QPoint(MyWindowWidth - MyBoardWOfs, 0));
            playerList.push_back(Player2);
            break;
        }
    case RobotPlayer:{
            setFixedSize(MyWindowWidth * 2 - MyBoardWOfs, MyWindowHeight);
            Player * Player1 = new Player(PlayerType::Local);
            playerList.push_back(Player1);
            Player * Player2 = new Player(PlayerType::Robot, QPoint(MyWindowWidth - MyBoardWOfs, 0));
            playerList.push_back(Player2);
            //连接定时器与人机决策函数
            //debug
            //qDebug()<<"robot connect"<<endl;
            connect(&timer_robot, SIGNAL(timeout()), this, SLOT(robotUpdate()));
            timer_robot.start(robotDecide);
            break;
        }
    case OnlinePlayer:{
            setFixedSize(MyWindowWidth * 2 - MyBoardWOfs, MyWindowHeight);
            Player * Player1 = new Player(PlayerType::Local);
            playerList.push_back(Player1);
            Player * Player2 = new Player(PlayerType::Online, QPoint(MyWindowWidth - MyBoardWOfs, 0));
            playerList.push_back(Player2);
            break;
        }
    }
}

int game::valueToIndex(int value){
    int index = 0;
    while(value > 0){
        value = value >> 1;
        index++;
    }
    return index;
}


void game::keyPressEvent(QKeyEvent * e){
    //用于区分收集到的是那个用户，开启对应用户的动画绘制定时器
    int player = 0;
    if(gameMode == SinglePlayer){
        switch (e->key()) {   
            case Qt::Key_W:
            playerList[0]->updateBoard(Qt::Key_W);
            break;
            case Qt::Key_A:
            playerList[0]->updateBoard(Qt::Key_A);
            break;
            case Qt::Key_D:
            playerList[0]->updateBoard(Qt::Key_D);
            break;
            case Qt::Key_S:
            playerList[0]->updateBoard(Qt::Key_S);
            default:
            break;
        }
    }
    else{
        switch (e->key()) {
            case Qt::Key_Up:
            playerList[1]->updateBoard(Qt::Key_W);
            player = 1;
            //debug
            qDebug()<<"keyEvent from player 1"<<endl;
            break;
            case Qt::Key_Left:
            playerList[1]->updateBoard(Qt::Key_A);
            player = 1;
            //debug
            qDebug()<<"keyEvent from player 1"<<endl;
            break;
            case Qt::Key_Right:
            playerList[1]->updateBoard(Qt::Key_D);
            player = 1;
            //debug
            qDebug()<<"keyEvent from player 1"<<endl;
            break;
            case Qt::Key_Down:
            playerList[1]->updateBoard(Qt::Key_S);
            player = 1;
            //debug
            qDebug()<<"keyEvent from player 1"<<endl;
            break;
            case Qt::Key_W:
            playerList[0]->updateBoard(Qt::Key_W);
            //debug
            qDebug()<<"keyEvent from player 0"<<endl;
            break;
            case Qt::Key_A:
            playerList[0]->updateBoard(Qt::Key_A);
            //debug
            qDebug()<<"keyEvent from player 0"<<endl;
            break;
            case Qt::Key_D:
            playerList[0]->updateBoard(Qt::Key_D);
            //debug
            qDebug()<<"keyEvent from player 0"<<endl;
            break;
            case Qt::Key_S:
            playerList[0]->updateBoard(Qt::Key_S);
            //debug
            qDebug()<<"keyEvent from player 0"<<endl;
            default:
            break;
        }
    }
    if(player == 0){
        timer_player0.start(frameTime);
        //debug
        //qDebug()<<"timer 0 start"<<endl;
    }else{
        timer_player1.start(frameTime);
        //debug
        //qDebug()<<"timer 1 start"<<endl;
    }
}

void game::paintEvent(QPaintEvent *){
    QPainter painter(this);
    //debug
    //qDebug()<<"paint event called"<<endl;

    for(int i = 0;i < playerList.size();i++){
        if(playerList[i]->waiting){//如果玩家i的棋盘正在绘制动画
            //若本次绘制动画后动画完成
            if(drawAnimation(painter, i)){
                playerList[i]->waiting = false;
                if(i == 0){
                    timer_player0.stop();
                    //debug
                    //qDebug()<<"timer"<<i<<"end"<<endl;
                }
                else{
                    timer_player1.stop();
                    //qDebug()<<"timer"<<i<<"end"<<endl;
                }
                playerList[i]->animationList.clear();
                //debug
                qDebug()<<"count "<<"i:"<<playerList[i]->count<<endl;
            }
        }
    }

    //绘制静态的棋盘图
    for(int i = 0;i < playerList.size();i++){
        //绘制对应玩家棋盘的背景，不描边
        //若玩家i正在绘制动画，则重复不绘制静态图，交由上面的drawAnimation与定时器逐帧绘制动画
        if(playerList[i]->waiting){
            //qDebug()<<"player"<<i<<"skip static graph drawing"<<endl;
            continue;
        }
        painter.setPen(Qt::transparent);
        painter.setBrush(BoardBkg);
        painter.drawRect(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs, MyBoardHOfs,
                         MyBoardSize + MyCellGap, MyBoardSize+ MyCellGap);
        //绘制分数栏
        painter.setPen(DefaultColor);
        painter.setFont(DefaultFont);
        QString str_score;
        painter.drawText(QPoint(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs,MyBoardHOfs - MyCellGap)
                         ,"分数:"+QString::number(playerList[i]->score));
        //绘制格子
        for(int j=0;j < MySize;j++){
            for(int k=0;k < MySize;k++){
                painter.setPen(Qt::transparent);
                int value = playerList[i]->board[j][k];
                painter.setBrush(CellBkg[valueToIndex(value)]);
                // 对格子上色
                painter.drawRect(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs + k * MyCellSize + MyCellGap,
                                 MyBoardHOfs + j * MyCellSize + MyCellGap,
                                 MyCellSize - MyCellGap,
                                 MyCellSize - MyCellGap);
                if(value != 0){
                    if(value>4) painter.setPen(HigherColor);
                    else painter.setPen(LowerColor);
                    painter.setFont(DigitFont);
                    //在方块中 绘制Text， 并且文本位置位于中部
                    painter.drawText(QRectF(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs + k * MyCellSize + MyCellGap,
                                     MyBoardHOfs + j * MyCellSize + MyCellGap,
                                     MyCellSize - MyCellGap,
                                     MyCellSize - MyCellGap),
                                     QString::number(value),QTextOption(Qt::AlignCenter));
                }
            }
        }
    }
}

bool game::drawAnimation(QPainter& painter, int i){
    bool done = true; //是否全部动画均已完成

    //在动态图绘制过程中也绘制必要的静态图：分数栏，棋盘背景，格子背景
    painter.setPen(Qt::transparent);
    painter.setBrush(BoardBkg);
    painter.drawRect(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs, MyBoardHOfs,
                     MyBoardSize + MyCellGap, MyBoardSize+ MyCellGap);
    //绘制分数栏
    painter.setPen(DefaultColor);
    painter.setFont(DefaultFont);
    QString str_score;
    painter.drawText(QPoint(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs,MyBoardHOfs - MyCellGap)
                     ,"分数:"+QString::number(playerList[i]->score));
    //绘制格子背景
    for(int j=0;j < MySize;j++){
        for(int k=0;k < MySize;k++){
            painter.setPen(Qt::transparent);
            painter.setBrush(CellBkg[0]);
            // 对格子上色
            painter.drawRect(i * (MyBoardWOfs + MyBoardSize) + MyBoardWOfs + k * MyCellSize + MyCellGap,
                             MyBoardHOfs + j * MyCellSize + MyCellGap,
                             MyCellSize - MyCellGap,
                             MyCellSize - MyCellGap);
        }
    }

    //循环为每个动画绘制一帧
    bool moveDone = true; //所有移动动画是否完成，保证出现动画在移动动画之后
    for(auto j = playerList[i]->animationList.begin();j != playerList[i]->animationList.end();j++){
        //绘制一帧玩家i动画列表中的动画
        if(!drawAnimationFrame(*j, painter, moveDone)){
            //若其中有一动画未完全绘制完（未达到最后一帧）
            done = false;
            //有移动动画未完成，暂不绘制新方格出现动画
            if(j->type == MOVE) moveDone = false;
        }
    }

    return done;
}

bool game::drawAnimationFrame(Animation& animate, QPainter& painter, bool moveDone){
    bool done = false;
    qreal start_x, start_y, end_x, end_y;
    start_x = animate.startPos.x();
    start_y = animate.startPos.y();
    end_x = animate.endPos.x();
    end_y = animate.endPos.y();
    //若动画类型为方格移动
    if(animate.type == MOVE){
        switch (animate.direct) {
            //判断移动方向
            case Qt::Key_W:{
                    //判断动画是否绘制完成
                    //因为每帧移动距离与格子距离未必成整倍数，用不等式判断
                    if(start_y > end_y){
                        start_y -= moveLength;
                        animate.startPos.setY(start_y);
                        //debug
                        //qDebug()<<"draw move up"<<endl;
                    }else{
                        animate.startPos.setY(end_y);
                        done = true;
                    }
                    break;
                }
            case Qt::Key_A:{
                    if(start_x > end_x){
                        start_x -= moveLength;
                        animate.startPos.setX(start_x);
                        //debug
                        //qDebug()<<"draw move left"<<endl;
                    }else{
                        animate.startPos.setX(end_x);
                        done = true;
                    }
                    break;
                }
            case Qt::Key_S:{
                    if(start_y < end_y){
                        start_y += moveLength;
                        animate.startPos.setY(start_y);
                        //debug
                        //qDebug()<<"draw move down"<<endl;
                    }else{
                        animate.startPos.setY(end_y);
                        done = true;
                    }
                    break;
                }
            case Qt::Key_D:{
                if(start_x < end_x){
                    start_x += moveLength;
                    animate.startPos.setX(start_x);
                    //debug
                    //qDebug()<<"draw move right"<<endl;
                }else{
                    animate.startPos.setX(end_x);
                    done = true;
                }
                break;
            }
        }
        //根据当前的坐标作出经过一帧的移动后的小方格
        //如果到达终点，则要显示终点时的数值（可能经过合并）
        if(!done){
            painter.setPen(Qt::transparent);
            int value = animate.digitStart;
            painter.setBrush(CellBkg[valueToIndex(value)]);
            // 对格子上色
            painter.drawRect(animate.startPos.x(),
                             animate.startPos.y(),
                             MyCellSize - MyCellGap,
                             MyCellSize - MyCellGap);
            if(value != 0){
                if(value>4) painter.setPen(HigherColor);
                else painter.setPen(LowerColor);
                painter.setFont(DigitFont);
                //在方块中 绘制Text， 并且文本位置位于中部
                painter.drawText(QRectF(animate.startPos.x(),
                                        animate.startPos.y(),
                                 MyCellSize - MyCellGap,
                                 MyCellSize - MyCellGap),
                                 QString::number(value),QTextOption(Qt::AlignCenter));
            }
        }else{
            painter.setPen(Qt::transparent);
            int value = animate.digitEnd;
            painter.setBrush(CellBkg[valueToIndex(value)]);
            // 对格子上色
            painter.drawRect(animate.endPos.x(),
                             animate.endPos.y(),
                             MyCellSize - MyCellGap,
                             MyCellSize - MyCellGap);
            if(value != 0){
                if(value>4) painter.setPen(HigherColor);
                else painter.setPen(LowerColor);
                painter.setFont(DigitFont);
                //在方块中 绘制Text， 并且文本位置位于中部
                painter.drawText(QRectF(animate.endPos.x(),
                                        animate.endPos.y(),
                                 MyCellSize - MyCellGap,
                                 MyCellSize - MyCellGap),
                                 QString::number(value),QTextOption(Qt::AlignCenter));
            }
        }
    }else{
    //动画类型为方格出现
    //有移动动画未完成，暂不绘制新方格出现动画
    if(!moveDone) return false;
        if(start_x > end_x){
            animate.startPos.setX(start_x -= moveLength/1.5);
            animate.startPos.setY(start_y -= moveLength/1.5);
        }else{
            animate.startPos.setX(end_x);
            animate.startPos.setY(end_y);
            done = true;
        }
        //作出逐渐变大的方格
        painter.setPen(Qt::transparent);
        int value = animate.digitStart;
        painter.setBrush(CellBkg[valueToIndex(value)]);
        // 对格子上色
        painter.drawRect(animate.startPos.x(),
                         animate.startPos.y(),
                         MyCellSize - MyCellGap - (start_x - end_x)*2,
                         MyCellSize - MyCellGap - (start_y - end_y)*2);
        if(value != 0){
            if(value>4) painter.setPen(HigherColor);
            else painter.setPen(LowerColor);
            painter.setFont(DigitFont);
            //在方块中 绘制Text， 并且文本位置位于中部
            painter.drawText(QRectF(animate.startPos.x(),
                                    animate.startPos.y(),
                                    MyCellSize - MyCellGap - (start_x - end_x)*2,
                                    MyCellSize - MyCellGap - (start_y - end_y)*2),
                             QString::number(value),QTextOption(Qt::AlignCenter));
        //qDebug()<<"appear"<<endl;
        }
    }
    //debug
    //if(done) qDebug()<<"a animation done"<<endl;
    return done;
}

void game::checkWin(){
    int i = 0;
    bool judge = false;
    for(i = 0;i < playerList.size();i++){
        if(!playerList[i]->waiting){
            for(int j = 0;j < MySize;j++){
                for(int k = 0;k < MySize;k++){
                    if(playerList[i]->board[j][k] == 2048){
                        judge = true;
                        break;
                    }
                }
                if(judge == true) break;
            }
        }
        if(judge == true) break;
    }
    if(judge == true){
        //debug
        qDebug()<<"called win"<<endl;
        QMessageBox::about(this, "游戏结束", "玩家" + QString::number(i+1) + "胜利");
        restartGame();
    }
}

void game::checkLose(){
    int i = 0;
    bool countStill = false;//全部玩家尚未结束游戏
    for(i = 0;i < playerList.size();i++){
        if(playerList[i]->count < MySize * MySize){
            countStill = true;
            break;
        }else{
            for(int j = 0;j < MySize;j++){
                for(int k = 0;k < MySize - 1;k++){
                    if(playerList[i]->board[j][k] == playerList[i]->board[j][k+1]){
                        countStill = true;
                        break;
                    }
                }
                if(countStill) break;
            }
            if(countStill) break;
            for(int j = 0;j < MySize;j++){
                for(int k = 0;k < MySize - 1;k++){
                    if(playerList[i]->board[k][j] == playerList[i]->board[k+1][j]){
                        countStill = true;
                        break;
                    }
                }
                if(countStill) break;
            }
        }
    }
    if(!countStill && playerList.size() > 1){
        if(playerList[0]->score > playerList[1]->score){
            QMessageBox::about(this, "游戏结束", "玩家" + QString::number(1) + "胜利");
            restartGame();
        }else if(playerList[0]->score < playerList[1]->score){
            QMessageBox::about(this, "游戏结束", "玩家" + QString::number(2) + "胜利");
            restartGame();
        }else{
            QMessageBox::about(this, "游戏结束", "平局");
            restartGame();
        }
    }else if(!countStill){
        QMessageBox::about(this, "游戏结束", "失败");
        restartGame();
    }
}


