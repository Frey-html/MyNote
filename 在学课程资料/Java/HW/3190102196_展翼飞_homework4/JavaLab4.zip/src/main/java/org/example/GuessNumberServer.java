package org.example;

import java.io.*;
import java.net.*;
import java.util.*;

public class GuessNumberServer {
    private static final int PORT = 12345;
    private static final int MAX_GUESS = 100;
    private static Random random = new Random();

    public static void main(String[] args) {
        System.out.println("Server started...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                // 等待客户端连接
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected!");

                // 为每个客户端创建一个处理线程
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private int targetNumber;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            this.targetNumber = random.nextInt(MAX_GUESS) + 1;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                out.println("Welcome to Guess the Number Game! The number is between 1 and 100.");
                String guess;
                while ((guess = in.readLine()) != null) {
                    try {
                        int userGuess = Integer.parseInt(guess);
                        if (userGuess < targetNumber) {
                            out.println("Too low! Try again.");
                        } else if (userGuess > targetNumber) {
                            out.println("Too high! Try again.");
                        } else {
                            out.println("Congratulations! You guessed the right number!");
                            break;
                        }
                    } catch (NumberFormatException e) {
                        out.println("Invalid input. Please enter a number.");
                    }
                }
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
