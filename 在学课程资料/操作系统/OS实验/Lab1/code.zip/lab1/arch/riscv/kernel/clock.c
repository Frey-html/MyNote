#include "sbi.h"
#include "stdint.h"

// QEMU 中时钟的频率是 10MHz，也就是 1 秒钟相当于 10000000 个时钟周期
uint64_t TIMECLOCK = 10000000;

// 获取当前的时钟周期
uint64_t get_cycles() {
    uint64_t cycles;
    __asm__ volatile (
        "rdtime %0"  // 使用 rdtime 指令读取当前时间寄存器的值
        : "=r" (cycles)  // 将读取到的值存储到 cycles 变量中
    );
    return cycles;  // 返回当前时钟周期
}

// 设置下一次时钟中断事件
void clock_set_next_event() {
    // 下一次时钟中断的时间点
    uint64_t next = get_cycles() + TIMECLOCK;

    // 使用 sbi_set_timer 来完成对下一次时钟中断的设置
    struct sbiret ret = sbi_set_timer(next);

    // 检查 ret.error 来判断是否设置成功
    if (ret.error != 0) {
        // 错误处理代码，可以打印错误信息
        printk("Error occor in clock_set_next_event\n");
    }
}
