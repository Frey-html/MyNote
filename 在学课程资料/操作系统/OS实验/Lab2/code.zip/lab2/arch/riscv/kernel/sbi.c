#include "stdint.h"
#include "sbi.h"

struct sbiret sbi_ecall(uint64_t eid, uint64_t fid,
                        uint64_t arg0, uint64_t arg1, uint64_t arg2,
                        uint64_t arg3, uint64_t arg4, uint64_t arg5) {
    struct sbiret ret;
    __asm__ volatile (
        "mv a7, %[eid]\n"        // 将 eid 放入寄存器 a7
        "mv a6, %[fid]\n"        // 将 fid 放入寄存器 a6
        "mv a0, %[arg0]\n"       // 将 arg0 放入寄存器 a0
        "mv a1, %[arg1]\n"       // 将 arg1 放入寄存器 a1
        "mv a2, %[arg2]\n"       // 将 arg2 放入寄存器 a2
        "mv a3, %[arg3]\n"       // 将 arg3 放入寄存器 a3
        "mv a4, %[arg4]\n"       // 将 arg4 放入寄存器 a4
        "mv a5, %[arg5]\n"       // 将 arg5 放入寄存器 a5
        "ecall\n"                // 触发系统调用
        "mv %[error], a0\n"      // 将返回的 error code 放入 ret.error
        "mv %[value], a1\n"      // 将返回的 value 放入 ret.value
        : [error] "=r" (ret.error), [value] "=r" (ret.value) // 输出操作数
        : [eid] "r" (eid), [fid] "r" (fid), 
          [arg0] "r" (arg0), [arg1] "r" (arg1), 
          [arg2] "r" (arg2), [arg3] "r" (arg3), 
          [arg4] "r" (arg4), [arg5] "r" (arg5) // 输入操作数
        : "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7" // 被修改的寄存器
    );

    return ret; // 返回结果
}

// 设置定时器
struct sbiret sbi_set_timer(uint64_t stime_value) {
    return sbi_ecall(0x54494D45, 0, stime_value, 0, 0, 0, 0, 0);
}

// 向终端写入数据
struct sbiret sbi_debug_console_write(uint8_t byte) {
    return sbi_ecall(0x4442434E, 0, byte, 0, 0, 0, 0, 0);
}

// 从终端读取数据
struct sbiret sbi_debug_console_read(void) {
    return sbi_ecall(0x4442434E, 1, 0, 0, 0, 0, 0, 0);
}

//向终端写入单个字符
struct sbiret sbi_debug_console_write_byte(uint8_t byte) {
    return sbi_ecall(0x4442434E, 2, byte, 0, 0, 0, 0, 0);
}

//重置系统（关机或重启）
struct sbiret sbi_system_reset(uint32_t reset_type, uint32_t reset_reason) {
    return sbi_ecall(0x53525354, 0, reset_type, reset_reason, 0, 0, 0, 0);
}
